package controller;

import dao.BookDAO;
import dao.ReservationDAO;
import model.Book;
import model.Reservation;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

@WebServlet(name = "ReservationServlet", urlPatterns = {"/ReservationServlet"})
public class ReservationServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        ReservationDAO reservationDAO = new ReservationDAO();
        List<Reservation> reservationList = reservationDAO.getReservationHistory();

        request.setAttribute("reservationList", reservationList);
        request.getRequestDispatcher("viewReservation.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String studentName = request.getParameter("studentName");
        String studentId = request.getParameter("studentId");
        int bookId = Integer.parseInt(request.getParameter("bookId"));

        BookDAO bookDAO = new BookDAO();
        Book book = bookDAO.getBookById(bookId);

        if (book == null) {
            request.setAttribute("errorMessage", "Book not found.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
            return;
        }

        ReservationDAO reservationDAO = new ReservationDAO();
        
        if (!reservationDAO.isBookAvailable(bookId)) {
            request.setAttribute("errorMessage", "Sorry, this book has already been reserved.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
            return;
        }

        try {
            Timestamp reservationDate = new Timestamp(System.currentTimeMillis());

            Reservation reservation = new Reservation();
            reservation.setStudentName(studentName);
            reservation.setStudentId(studentId);
            reservation.setBookId(bookId);
            reservation.setReservationDate(reservationDate);

            reservationDAO.reserveBook(reservation);
            
            request.setAttribute("successMessage", "Book '" + book.getTitle() + "' has been reserved successfully!");
            request.getRequestDispatcher("success.jsp").forward(request, response);

        } catch (SQLException e) {
            request.setAttribute("errorMessage", "An error occurred while reserving the book: " + e.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }

    @Override
    public String getServletInfo() {
        return "Handles book reservation requests";
    }
}
