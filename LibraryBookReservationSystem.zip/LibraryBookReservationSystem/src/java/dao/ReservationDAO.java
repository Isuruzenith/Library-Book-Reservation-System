package dao;

import model.Reservation;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ReservationDAO {

    private final String jdbcURL = "jdbc:mysql://localhost:3306/librarydb";
    private final String jdbcUsername = "root";
    private final String jdbcPassword = "";

    private Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database driver not found", e);
        }
    }

    public boolean isBookAvailable(int bookId) {
        String sql = "SELECT status FROM books WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, bookId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return "Available".equalsIgnoreCase(rs.getString("status"));
            }
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void reserveBook(Reservation reservation) throws SQLException {
        if (!isBookAvailable(reservation.getBookId())) {
            throw new SQLException("Book is not available for reservation");
        }

        String sql = "INSERT INTO reservations (student_name, student_id, book_id, reservation_date) VALUES (?, ?, ?, ?)";
        String updateBookSql = "UPDATE books SET status = 'Reserved' WHERE id = ?";

        Connection conn = null;
        try {
            conn = getConnection();
            conn.setAutoCommit(false);

            // Insert reservation
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, reservation.getStudentName());
                stmt.setString(2, reservation.getStudentId());
                stmt.setInt(3, reservation.getBookId());
                stmt.setTimestamp(4, reservation.getReservationDate());
                stmt.executeUpdate();
            }

            // Update book status
            try (PreparedStatement stmt = conn.prepareStatement(updateBookSql)) {
                stmt.setInt(1, reservation.getBookId());
                stmt.executeUpdate();
            }

            conn.commit();
        } catch (SQLException e) {
            if (conn != null) {
                conn.rollback();
            }
            throw e;
        } finally {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        }
    }
    
    public List<Reservation> getReservationHistory() {
        List<Reservation> reservationList = new ArrayList<>();
        String sql = "SELECT r.*, b.title, b.author FROM reservations r " +
                    "JOIN books b ON r.book_id = b.id " +
                    "ORDER BY r.reservation_date DESC";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Reservation res = new Reservation();
                res.setId(rs.getInt("id"));
                res.setStudentName(rs.getString("student_name"));
                res.setStudentId(rs.getString("student_id"));
                res.setBookId(rs.getInt("book_id"));
                res.setReservationDate(rs.getTimestamp("reservation_date"));
                res.setBookTitle(rs.getString("title"));
                res.setBookAuthor(rs.getString("author"));
                reservationList.add(res);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reservationList;
    }
}

