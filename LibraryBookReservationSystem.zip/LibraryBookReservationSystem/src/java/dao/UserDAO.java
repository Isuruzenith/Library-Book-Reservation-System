package dao;

import model.User;
import java.sql.*;

public class UserDAO {
    private final String jdbcURL = "jdbc:mysql://localhost:3306/librarydb";
    private final String jdbcUsername = "root";
    private final String jdbcPassword = "";

    public UserDAO() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection jdbcConnection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            if (jdbcConnection != null) {
                System.out.println("Connection to the database was successful!");
                jdbcConnection.close();
            } else {
                System.out.println("Failed to make connection to the database.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
    }

    public User validateUser(String username, String password) {
        User user = null;

        try (Connection conn = getConnection()) {
            String sql = "SELECT * FROM users WHERE username=? AND password=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setRole(rs.getString("role"));
            }
        } catch (Exception e) {
        }
        return user;
    }

}
